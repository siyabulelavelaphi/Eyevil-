const products = [
  {id:1,name:"EYEVIL Diamond Eye Tee",type:"clothing",price:250,image:"images/shirt-design-1.jpg",tag:"NEW",desc:"EYEVIL diamond-eye graphic T-shirt."},
  {id:2,name:"EYEVIL Photographer Tee",type:"clothing",price:250,image:"images/shirt-design-2.png",tag:"NEW",desc:"EYEVIL photographer graphic T-shirt."},
  {id:3,name:"EYEVIL Face Graphic Tee",type:"clothing",price:250,image:"images/shirt-design-3.png",tag:"NEW",desc:"EYEVIL face graphic T-shirt."},
  {id:4,name:"EYEVIL Hands & Eyes Tee",type:"clothing",price:250,image:"images/shirt-design-4.png",tag:"NEW",desc:"EYEVIL hands-and-eyes graphic T-shirt."},
  {id:5,name:"EYEVIL Red Logo Tee",type:"clothing",price:250,image:"images/shirt-design-5.png",tag:"POPULAR",desc:"EYEVIL red logo graphic T-shirt."},
  {id:6,name:"THE EYEVIL Sharp Eye Tee",type:"clothing",price:250,image:"images/shirt-design-6.png",tag:"POPULAR",desc:"THE EYEVIL sharp-eye text T-shirt."},
  {id:7,name:"EYEVIL Grey Graphic Tee",type:"clothing",price:250,image:"images/shirt-design-7.png",tag:"NEW",desc:"EYEVIL grey graphic T-shirt."}
];

const colors = ["White","Yellow","Red","Black"];
let cart = JSON.parse(localStorage.getItem("eyevilCart") || "[]");
const productsEl = document.getElementById("products");
const searchEl = document.getElementById("search");

function money(n){ return "R" + n.toFixed(2); }

function renderProducts(filter="all", query=""){
  const q = query.toLowerCase().trim();
  const list = products.filter(p =>
    (filter==="all" || p.type===filter) &&
    (!q || p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q))
  );

  productsEl.innerHTML = list.length ? list.map(p => `
    <article class="product">
      <div class="product-img">
        <img src="${p.image}" alt="${p.name}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;">
      </div>
      <span class="tag">${p.tag}</span>
      <h3>${p.name}</h3>
      <p>${p.desc}</p>
      <div class="price">${money(p.price)}</div>
      <label style="display:block;margin:10px 0 6px;font-size:14px;">Colour</label>
      <select id="color-${p.id}" style="width:100%;padding:10px;border-radius:8px;">
        ${colors.map(c => `<option value="${c}">${c}</option>`).join("")}
      </select>
      <button class="add" onclick="addToCart(${p.id})">ADD TO CART</button>
    </article>
  `).join("") : `<p style="color:#999">No products found.</p>`;
}

function addToCart(id){
  const colorEl = document.getElementById(`color-${id}`);
  const color = colorEl ? colorEl.value : "White";
  cart.push({id:id,color:color});
  saveCart();
  openCart();
}

function removeFromCart(index){
  cart.splice(index,1);
  saveCart();
}

function saveCart(){
  localStorage.setItem("eyevilCart",JSON.stringify(cart));
  renderCart();
}

function renderCart(){
  document.getElementById("cartCount").textContent = cart.length;

  const items = cart.map((item,index) => {
    // Supports old cart entries that were saved as plain product IDs.
    const id = typeof item === "object" ? item.id : item;
    const color = typeof item === "object" ? item.color : "White";
    const product = products.find(p => p.id === id);
    return product ? {...product, color, cartIndex:index} : null;
  }).filter(Boolean);

  document.getElementById("cartItems").innerHTML = items.length ? items.map(item => `
    <div class="cart-row">
      <div>
        <b>${item.name}</b><br>
        <small>Colour: ${item.color} · ${money(item.price)}</small>
      </div>
      <button class="remove" onclick="removeFromCart(${item.cartIndex})">Remove</button>
    </div>
  `).join("") : `<p style="color:#888">Your cart is empty.</p>`;

  document.getElementById("cartTotal").textContent =
    money(items.reduce((s,p) => s + p.price, 0));
}

function openCart(){
  document.getElementById("cart").classList.add("open");
  document.getElementById("overlay").classList.add("show");
}

function closeCart(){
  document.getElementById("cart").classList.remove("open");
  document.getElementById("overlay").classList.remove("show");
}

document.getElementById("cartBtn").onclick = openCart;
document.getElementById("closeCart").onclick = closeCart;
document.getElementById("overlay").onclick = closeCart;

document.getElementById("checkoutBtn").onclick = () =>
  alert("Checkout is not connected yet. Your store is ready for a payment provider when you choose one.");

document.querySelectorAll(".filter").forEach(b => b.onclick = () => {
  document.querySelectorAll(".filter").forEach(x => x.classList.remove("active"));
  b.classList.add("active");
  renderProducts(b.dataset.filter, searchEl.value);
});

document.querySelectorAll(".categories a").forEach(a => a.onclick = () => {
  const f = a.dataset.filter;
  document.querySelectorAll(".filter").forEach(x =>
    x.classList.toggle("active", x.dataset.filter === f)
  );
  renderProducts(f, "");
});

searchEl.addEventListener("input", () => {
  const active = document.querySelector(".filter.active").dataset.filter;
  renderProducts(active, searchEl.value);
});

renderProducts();
renderCart();
